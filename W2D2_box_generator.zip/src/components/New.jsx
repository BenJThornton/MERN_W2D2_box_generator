import React, {useState} from 'react'

const New = (props) =>{

    const [newColor, setNewColor] = useState("")

    const submitColor = (e) => {
        e.preventDefault();
        const newBox = {
            color: newColor
        }

        props.createBox(newBox);
    }

    return(
        <div>
            <form onSubmit={submitColor}>
                <input type="text" onChange={e => setNewColor(e.target.value)} value={newColor}/>
                <button>Add</button>
            </form>
            <hr />
        </div>
    )
}

export default New