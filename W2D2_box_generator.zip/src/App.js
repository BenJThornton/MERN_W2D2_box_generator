
import './App.css';
import React, {useState} from 'react';
import Box from './components/Box';
import New from './components/New';

function App() {
  const [boxes, setBoxes] = useState(
    [
      {color: "red"},
      {color: "blue"},
      {color: "green"},
    ]
  )

  //CREATE NEW BOX
  const createBox = (newBoxObj) => {
    
    const copyBoxes = [...boxes];
    copyBoxes.push(newBoxObj);
    setBoxes(copyBoxes)

    //SHORTHAND for code above is listed below:
    //setBoxes([...boxes, newBoxObj])
  }
  return (
    <div className="App">
      <h1>Boxes</h1>
      <hr />
      <New createBox={createBox}/>
      {
        boxes.map( (box, idx) => {
          return <Box box={box} key={idx}/>
        })
      }
    </div>
  );
}

export default App;
